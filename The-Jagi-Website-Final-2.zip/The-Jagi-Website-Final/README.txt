THE JAGI WEBSITE

1. Open index.html in a browser to view the website.
2. Keep the images folder in the same location as index.html.
3. The website is responsive for desktop and mobile screens.
4. Product and website reference images are included in the images folder.
